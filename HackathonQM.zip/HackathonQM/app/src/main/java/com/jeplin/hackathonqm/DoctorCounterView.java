package com.jeplin.hackathonqm;

import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.jeplin.hackathonqm.RetroFit.DoctorNextPojo.DoctorNextData;
import com.jeplin.hackathonqm.RetroFit.DoctorPojo.DoctorData;
import com.jeplin.hackathonqm.RetroFit.UserService;

import org.json.JSONException;
import org.json.JSONObject;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DoctorCounterView extends AppCompatActivity {
    //JSONObject jsonObject;

    TextView doctorName,curretAppointmentStatus,patientName,patientDepartment,patientNumber,patientEmail;
    Button BTN_NEXT;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_counter_view);

        declareVariable();
        getDoctorData();
    }
    public void declareVariable(){
        doctorName=(TextView)findViewById(R.id.txt_hi_doctor);
        curretAppointmentStatus=(TextView)findViewById(R.id.txt_curr_token);
        patientName=(TextView)findViewById(R.id.txt_patient);
        patientDepartment=(TextView)findViewById(R.id.txt_department);
        patientNumber=(TextView)findViewById(R.id.txt_mobile);
        patientEmail=(TextView)findViewById(R.id.txt_email);
        BTN_NEXT=(Button)findViewById(R.id.btn_next);
        BTN_NEXT.setEnabled(true);
        emptyAllVariable();
    }
    public void emptyAllVariable(){
        doctorName.setText("");
        curretAppointmentStatus.setText("");
        patientName.setText("");
        patientDepartment.setText("");
        patientNumber.setText("");
        patientEmail.setText("");
    }
    public void getDoctorData(){
//        String jsonPatientStr="{\"status\":true,\"data\":{\"patient_name\":\"ABC\",\"department\":\"Medicine\",\"floor\":2,\"room_number\":45,\"doctor_name\":\"Dr. Summit Verma\",\"patient_phone\":9914466774,\"patient_email\":\"hjhjhj@gmail.com\",\"crno\":545454545,\"waiting_hall\":\"XZ\",\"patient_token\":5,\"token_status\":1,\"token_total\":10}}";
//        String jsonDoctorPhoneStr="{\"status\":true,\"otp\":1234,\"data\":{\"name\":\"Dr.Summet Verma\",\"phone\":9914477885,\"department\":\"Medicine\",\"floor\":2,\"room_no\":45,\"token_total\":50}}";
//        String jsonPhoneNumberStr="{\"status\":true,\"otp\":1234,\"data\":{\"patient\":{\"name\":\"ABC\",\"department\":\"Medicine\",\"floor\":2,\"room_number\":45,\"doctor_name\":\"Dr. Summit Verma\",\"phone\":9914466774,\"email\":\"hjhjhj@gmail.com\",\"crno\":545454545,\"waiting_hall\":\"XZ\",\"token\":5},\"token\":{\"status\":1,\"total\":10}}}";
//
//        try {
//            //Doctor Data
////            jsonObject=new JSONObject(jsonDoctorPhoneStr);
////            JSONObject dataObj=jsonObject.getJSONObject("data");
//            //Patient Data
//            JSONObject patientData=new JSONObject(jsonPhoneNumberStr);
//            JSONObject patientObj=patientData.getJSONObject("data");
//
//            //Log.d("data1","Data ---"+patientObj);
//            setDataInUI(patientObj);
//
//        } catch (JSONException e) {
//            e.printStackTrace();
//            Log.d("Catch","Error 1");
//        }

        SharedPreferences sharedPreferences=getSharedPreferences("doctorLogin",MODE_PRIVATE);

        String doctorNumber=sharedPreferences.getString("doctorNumber","");

        ApiConnectionData(doctorNumber);


    }
    public void ApiConnectionData(String DOCTOR_NUMBER){
        UserService.getApiClient().getDoctorNextData(DOCTOR_NUMBER).enqueue(new Callback<DoctorNextData>() {
            @Override
            public void onResponse(Call<DoctorNextData> call, Response<DoctorNextData> response) {
                if (response.isSuccessful()){

                    String status=response.body().getData().getToken().getStatus().toString();
                    String total=response.body().getData().getToken().getTotal().toString();

                    if (status.equals(total)){
                        BTN_NEXT.setEnabled(false);
                    }

                    setDataInUI(response.body());



                }
                else{
                    Toast.makeText(DoctorCounterView.this,"Data Not Available",Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<DoctorNextData> call, Throwable t) {
                Toast.makeText(DoctorCounterView.this,"Unable to fetch data from Server.",Toast.LENGTH_SHORT).show();
            }
        });
    }
    public void setDataInUI(DoctorNextData jsonData){
            //Display Doctor name
            //JSONObject patientObj=patientData.getJSONObject("patient");
            doctorName.setText("Hi!  "+jsonData.getData().getPatient().getDoctorName().toString());
            //Display Patient
            patientName.setText(jsonData.getData().getPatient().getName().toString());
            patientDepartment.setText(jsonData.getData().getPatient().getDepartment().toString());
            patientNumber.setText(jsonData.getData().getPatient().getPhone().toString());
            patientEmail.setText(jsonData.getData().getPatient().getEmail().toString());


            //JSONObject tokenData=patientData.getJSONObject("token");
            String tokenStr=jsonData.getData().getToken().getStatus().toString()+" / "+jsonData.getData().getToken().getTotal().toString();
            curretAppointmentStatus.setText(tokenStr);

    }
    public void nextBtnMethod(View v){
        Log.d("Next","Next Button Clicked");

        Toast.makeText(this,"Next Patient!",Toast.LENGTH_SHORT).show();
        getDoctorData();
    }
}
