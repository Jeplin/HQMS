package com.jeplin.posapp.Retrofit.Admin.getLayout;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class GetLayout {

@SerializedName("id")
@Expose
private String id;
@SerializedName("status")
@Expose
private String status;
@SerializedName("admin_id")
@Expose
private String adminId;
@SerializedName("number_of_floor")
@Expose
private String numberOfFloor;
@SerializedName("floors")
@Expose
private List<Floor> floors = null;
@SerializedName("modified_date")
@Expose
private String modifiedDate;

public String getId() {
return id;
}

public void setId(String id) {
this.id = id;
}

public String getStatus() {
return status;
}

public void setStatus(String status) {
this.status = status;
}

public String getAdminId() {
return adminId;
}

public void setAdminId(String adminId) {
this.adminId = adminId;
}

public String getNumberOfFloor() {
return numberOfFloor;
}

public void setNumberOfFloor(String numberOfFloor) {
this.numberOfFloor = numberOfFloor;
}

public List<Floor> getFloors() {
return floors;
}

public void setFloors(List<Floor> floors) {
this.floors = floors;
}

public String getModifiedDate() {
return modifiedDate;
}

public void setModifiedDate(String modifiedDate) {
this.modifiedDate = modifiedDate;
}

}