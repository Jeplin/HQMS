package com.jeplin.posapp.NavPage;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import com.jeplin.posapp.R;

/**
 * Created by jeplin on 11-12-2017.
 */

public class Frag_Admin_Create_layout extends Fragment{

    //Declare Components
    Button Btn_Save_Exit,Btn_Save_AddTable;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater,ViewGroup container, Bundle savedInstanceState) {
        //Define a Layout View
        View myView=inflater.inflate(R.layout.frag_admin_create_layout,null);

        //Toast.makeText(getActivity(),"Create layout Called",Toast.LENGTH_SHORT).show();

        //Define Button
        Btn_Save_Exit=(Button)myView.findViewById(R.id.btn_Save_Exit);
        Btn_Save_Exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                FragmentManager fm=getActivity().getSupportFragmentManager();
                fm.beginTransaction().replace(R.id.content_admin_id,new Frag_Admin_Home()).commit();
            }
        });

        Btn_Save_AddTable=(Button)myView.findViewById(R.id.btn_save_addTable);
        Btn_Save_AddTable.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentManager fm=getActivity().getSupportFragmentManager();
                fm.beginTransaction().replace(R.id.content_admin_id,new Frag_Admin_Add_Table()).commit();
            }
        });

        return myView;
    }
}
