package com.jeplin.posapp.Retrofit.Admin.getLayout;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Floor {

@SerializedName("id")
@Expose
private String id;
@SerializedName("layout_id")
@Expose
private String layoutId;
@SerializedName("number_of_table")
@Expose
private String numberOfTable;
@SerializedName("tables")
@Expose
private List<Table> tables = null;
@SerializedName("modified_date")
@Expose
private String modifiedDate;

public String getId() {
return id;
}

public void setId(String id) {
this.id = id;
}

public String getLayoutId() {
return layoutId;
}

public void setLayoutId(String layoutId) {
this.layoutId = layoutId;
}

public String getNumberOfTable() {
return numberOfTable;
}

public void setNumberOfTable(String numberOfTable) {
this.numberOfTable = numberOfTable;
}

public List<Table> getTables() {
return tables;
}

public void setTables(List<Table> tables) {
this.tables = tables;
}

public String getModifiedDate() {
return modifiedDate;
}

public void setModifiedDate(String modifiedDate) {
this.modifiedDate = modifiedDate;
}

}