package com.jeplin.posapp.Retrofit;

import com.google.gson.JsonElement;
import com.jeplin.posapp.Retrofit.Admin.getLayout.GetLayout;
import com.jeplin.posapp.Retrofit.sample.Sampleapus;

import org.json.JSONObject;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.http.GET;

/**
 * Created by jeplin on 21-12-2017.
 */

public interface ApiInterface {

    @GET("getLayout.php")
    Call<GetLayout> getLayout();

    @GET("/users")
    Call<Sampleapus> getData();

}
