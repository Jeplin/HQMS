package com.jeplin.posapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.GridView;
import com.jeplin.posapp.User.GridAdaptor;

public class UserHomeActivity extends AppCompatActivity {

    GridView myGridView;

    String[] values={
            "value 1",
            "value 2",
            "value 3",
            "value 4",
            "value 5",
            "value 6",
            "value 7",
            "value 8",
            "value 9",
            "value 10",
            "value 11"

    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_home);

        myGridView=(GridView)findViewById(R.id.gridView);

       GridAdaptor gridAdaptor=new GridAdaptor(this,values, false);
       myGridView.setAdapter(gridAdaptor);


    }
}
