package com.jeplin.posapp.Admin;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.jeplin.posapp.AdminMain;
import com.jeplin.posapp.R;
import com.jeplin.posapp.UserHomeActivity;

/**
 * Created by jeplin on 16-12-2017.
 */

public class Admin_GridAdaptor extends BaseAdapter {

    Context context;
    private final  String [] values;
    private final Boolean isEdit;
    private  final Boolean isDelete;
    View view;
    LayoutInflater layoutInflater;

    public Admin_GridAdaptor(Context context,String[] values,Boolean isEdit, Boolean isDelete) {
        this.context=context;
        this.values = values;
        this.isEdit=isEdit;
        this.isDelete = isDelete;
        this.view = view;
    }

    @Override
    public int getCount() {
        return values.length;
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        layoutInflater=(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        if (view == null){
            view=new View(context);
            view=layoutInflater.inflate(R.layout.admin_grid_item,null);
            TextView textView=(TextView)view.findViewById(R.id.txt_values);
            textView.setText(values[i]);

//            FrameLayout txtDeleteTable=(FrameLayout)view.findViewById(R.id.fram_deleteTable);
            TextView img_editTable=(TextView) view.findViewById(R.id.img_editTable);
            TextView img_deleteTable=(TextView) view.findViewById(R.id.img_deleteTable);

            if (isEdit){
                img_editTable.setVisibility(View.VISIBLE);
            }
            else {
                img_editTable.setVisibility(View.GONE);
            }
            if (isDelete){
                img_deleteTable.setVisibility(View.VISIBLE);
            }
            else{
                img_deleteTable.setVisibility(View.GONE);
            }

        }

        return view;
    }
}
