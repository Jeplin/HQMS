package com.jeplin.posapp.Retrofit.Admin.getLayout;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Table {

@SerializedName("id")
@Expose
private String id;
@SerializedName("floor_id")
@Expose
private String floorId;
@SerializedName("table_capacity")
@Expose
private String tableCapacity;
@SerializedName("modified_date")
@Expose
private String modifiedDate;

public String getId() {
return id;
}

public void setId(String id) {
this.id = id;
}

public String getFloorId() {
return floorId;
}

public void setFloorId(String floorId) {
this.floorId = floorId;
}

public String getTableCapacity() {
return tableCapacity;
}

public void setTableCapacity(String tableCapacity) {
this.tableCapacity = tableCapacity;
}

public String getModifiedDate() {
return modifiedDate;
}

public void setModifiedDate(String modifiedDate) {
this.modifiedDate = modifiedDate;
}

}