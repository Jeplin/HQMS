package com.jeplin.posapp.NavPage;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.Toast;

import com.google.gson.JsonElement;
import com.jeplin.posapp.Admin.Admin_GridAdaptor;
import com.jeplin.posapp.R;
import com.jeplin.posapp.Retrofit.Admin.getLayout.GetLayout;
import com.jeplin.posapp.Retrofit.ApiService;
import com.jeplin.posapp.Retrofit.sample.Sampleapus;

import org.json.JSONObject;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by jeplin on 11-12-2017.
 */

public class Frag_Admin_Home extends Fragment {

    GridView myGridView;
    FrameLayout fram_CreateLayout,fram_CreateTables,fram_GridView;
    Button Btn_GridEdit,Btn_AddGridTable,Btn_DeleteGridTable;

    private ArrayAdapter<String> adaptor;
    private static String[] values={
            "value 1",
            "value 2",
            "value 3",
            "value 4",
            "value 5",
            "value 6",
            "value 7",
            "value 8",
            "value 9",
            "value 10",
            "value 11"

    };

    int layout_Flag=0;
    int table_Flag=0;


    Boolean flag_EditBtn=false;
    Boolean flag_delTableBtn=false;

    // Declare Create Layout Button
    Button BTN_CreateLayout;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) {

        flag_EditBtn=false;
        //View myView=inflater.inflate(R.layout.frag_admin_home,container,false);
        View myView=inflater.inflate(R.layout.frag_admin_home,null);
        //Declare Frame Create layout Container
        fram_CreateLayout=(FrameLayout)myView.findViewById(R.id.fram_CreateLayout);

        //Declare Frame Create table Container
        fram_CreateTables=(FrameLayout)myView.findViewById(R.id.fram_CreateTables);
        fram_CreateTables.setVisibility(View.GONE);
        //Declare frame Grid View
        fram_GridView=(FrameLayout)myView.findViewById(R.id.fram_GridView);
        fram_GridView.setVisibility(View.GONE);

        Btn_GridEdit=(Button)myView.findViewById(R.id.btn_editGrid);
        //Declare Grid Editable Button
        Btn_AddGridTable=(Button)myView.findViewById(R.id.btn_add_GridTable);
//        Btn_AddGridTable.setVisibility(View.GONE);
        Btn_AddGridTable.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentManager fragmentManager=getActivity().getSupportFragmentManager();
                fragmentManager.beginTransaction().replace(R.id.content_admin_id,new Frag_Admin_Add_Table()).commit();
            }
        });

        Btn_DeleteGridTable=(Button)myView.findViewById(R.id.btn_delete_GridTable);
//        Btn_DeleteGridTable.setVisibility(View.GONE);
        Btn_DeleteGridTable.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                flag_delTableBtn=!flag_delTableBtn;
                flag_EditBtn=false;
                Btn_GridEdit.setText("Edit");
                declareGridView(flag_EditBtn,flag_delTableBtn);
            }
        });


        Btn_GridEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                flag_EditBtn=!flag_EditBtn;
                if (flag_EditBtn){
                    flag_delTableBtn=false;
                    Btn_GridEdit.setText("DONE");
//                    Btn_AddGridTable.setVisibility(View.VISIBLE);
//                    Btn_DeleteGridTable.setVisibility(View.VISIBLE);
                    declareGridView(flag_EditBtn,flag_delTableBtn);
                }else {
                    flag_delTableBtn=false;
                    flag_EditBtn=false;
                    Btn_GridEdit.setText("EDIT");
//                    Btn_AddGridTable.setVisibility(View.GONE);
//                    Btn_DeleteGridTable.setVisibility(View.GONE);
                    declareGridView(flag_EditBtn,flag_delTableBtn);
                }
            }
        });


        //Declare GridView
        myGridView=(GridView)myView.findViewById(R.id.adminGridView1);

        //Toast.makeText(getActivity(),"Admin Homne Called",Toast.LENGTH_SHORT).show();
        // Create Layout Button
        BTN_CreateLayout=(Button)myView.findViewById(R.id.btn_Create_Layout);
        BTN_CreateLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Toast.makeText(getActivity(),"Create layout Clicked",Toast.LENGTH_SHORT).show();
                FragmentManager fragmentManager=getActivity().getSupportFragmentManager();
                fragmentManager.beginTransaction().replace(R.id.content_admin_id,new Frag_Admin_Create_layout()).commit();
            }
        });



        getLayoutData();

        return myView;

    }

    public void getLayoutData(){


        ApiService.getApiClient().getLayout().enqueue(new Callback<GetLayout>() {
            @Override
            public void onResponse(Call<GetLayout> call, Response<GetLayout> response) {
                if (response.isSuccessful()){
                    Toast.makeText(getActivity(),"Data Available",Toast.LENGTH_SHORT).show();

                    GetLayout jsonObject=response.body();
                    Log.d("JSONData","Data :"+jsonObject);
                    layoutDataStore(jsonObject);
                }
                else {
                    Toast.makeText(getActivity(),"Data Not Available!",Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<GetLayout> call, Throwable t) {
                Toast.makeText(getActivity(),"Unable to Fetch Data from server.",Toast.LENGTH_SHORT).show();
                layout_Flag=0;
                table_Flag=0;
                displayUIMethod();
            }
        });
    }
    public void layoutDataStore(GetLayout jsonData){
        layout_Flag=1;
        table_Flag=0;

        displayUIMethod();
    }
    public void displayUIMethod(){
        if (layout_Flag==0){
            fram_CreateLayout.setVisibility(View.VISIBLE);
            fram_CreateTables.setVisibility(View.GONE);
            fram_GridView.setVisibility(View.GONE);

        }
        else{
            if (table_Flag==0){
                fram_CreateTables.setVisibility(View.VISIBLE);
                fram_CreateLayout.setVisibility(View.GONE);
                fram_GridView.setVisibility(View.GONE);

            }
            else{
                fram_CreateTables.setVisibility(View.GONE);
                fram_CreateLayout.setVisibility(View.GONE);
                fram_GridView.setVisibility(View.VISIBLE);
                declareGridView(false,false);
            }
        }
    }
    public void declareGridView(Boolean isEdit,Boolean isDelete){
        Admin_GridAdaptor gridAdaptor=new Admin_GridAdaptor(getActivity(),values,isEdit,isDelete);
        myGridView.setAdapter(gridAdaptor);

        myGridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                Toast.makeText(getActivity(),"Item Clicked : "+i,Toast.LENGTH_SHORT).show();
//                FragmentManager fragmentManager=getActivity().getSupportFragmentManager();
//                fragmentManager.beginTransaction().replace(R.id.content_admin_id,new Frag_Admin_Add_Table()).commit();
            }
        });

        myGridView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {

                //Toast.makeText(getActivity(),"Item Long Clicked : "+i,Toast.LENGTH_SHORT).show();

                return true;
            }
        });
    }
}
