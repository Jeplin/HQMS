package com.jeplin.posapp.NavPage;

import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.jeplin.posapp.R;

import java.util.ArrayList;

/**
 * Created by jeplin on 11-12-2017.
 */

public class Frag_Admin_Add_Table extends Fragment {

    private static String TAG = "AddTable";

    private static ArrayList<Float> yData=new ArrayList<>();

    private String[] xData={"Name1","Name2","Name3","Name4","Name5","Name6"};
    // Declare Color Array
    //Add Color to Slice
    private static ArrayList<Integer> colors=new ArrayList<>();
    // Declare Pie Chart
    PieChart pieChart;

    //Declare Button
    Button Btn_Add,Btn_Remove;

    int DIVIDER=0;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        //Declare a fragment View
        View myView=inflater.inflate(R.layout.frag_admin_add_table,null);
        //Pie Chart Declaration
        pieChart=(PieChart)myView.findViewById(R.id.myPieChart);

        declarePieChartMethod();

        if (DIVIDER==0)
        {
            pieDataMethod(DIVIDER+1);
        }else {
            pieDataMethod(DIVIDER);
        }

        //Add Button Define
        Btn_Add=(Button)myView.findViewById(R.id.btn_AddTable);
        Btn_Add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addMethodBtnClicked();
            }
        });

        //Remove Button Define
        Btn_Remove=(Button)myView.findViewById(R.id.btn_removeTable);
        Btn_Remove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                removeMethodBtnClicked();
            }
        });

        return myView;
    }
    public void declarePieChartMethod(){
        pieChart.setRotationEnabled(true);
        pieChart.getDescription().setText("");
        //pieChart.setUsePercentValues(true);
        pieChart.setHoleColor(Color.parseColor("#424242"));
        pieChart.setHoleRadius(70f);
        pieChart.setTransparentCircleAlpha(5);
        pieChart.setCenterText("Table Capacity\n"+ DIVIDER/2 );
        pieChart.setCenterTextColor(Color.WHITE);
        pieChart.setCenterTextSize(25);
        //pieChart.setEntryLabelTextSize(20);
        pieChart.setDrawEntryLabels(false);
    }

    public void pieDataMethod(int divider){
        pieChart.setCenterText("Table Capacity\n"+ DIVIDER/2 );

        yData.removeAll(yData);
        colors.removeAll(colors);

        if (divider>2){
            //Toast.makeText(getActivity(),"if called",Toast.LENGTH_SHORT).show();
            float dividedData=100/divider;
            for (int i=0;i<divider;i++){
                yData.add(dividedData);
                    if (i % 2 == 0) {
                        colors.add(Color.parseColor("#1b1b1b"));
                    } else {
                        colors.add(Color.WHITE);
                    }
            }
        }else{
            //Toast.makeText(getActivity(),"else called",Toast.LENGTH_SHORT).show();
            if (divider>1){
                yData.add(25f);
                colors.add(Color.parseColor("#1b1b1b"));
                yData.add(75f);
                colors.add(Color.WHITE);
            }
            else{
                yData.add(100f);
                colors.add(Color.WHITE);
            }
        }

        addDataTOChart();
    }

    private void addDataTOChart() {
        ArrayList<PieEntry> yEntry=new ArrayList<>();
        ArrayList<String> xEntry=new ArrayList<>();

        for (int i=0;i<yData.size();i++){
            Log.d(TAG,"y Data :"+yData.get(i));
            yEntry.add(new PieEntry(yData.get(i),i));
        }
        for (int i=0;i<xData.length;i++){
            xEntry.add(xData[i]);
        }

        //Create Data set for Pie
        PieDataSet pieDataSet=new PieDataSet(yEntry,"Some Labels");
        pieDataSet.setSliceSpace(2);
        pieDataSet.setValueTextSize(12);
        pieDataSet.setDrawValues(false);
        // Add Colors to Pie Chart
        pieDataSet.setColors(colors);

        //add Legend to Chart
        Legend legend=pieChart.getLegend();
        legend.setEnabled(false);
        legend.setForm(Legend.LegendForm.CIRCLE);

        //Create pie data object
        PieData pieData=new PieData(pieDataSet);
        pieChart.setData(pieData);
        pieChart.invalidate();
    }

    public void addMethodBtnClicked(){
        //Toast.makeText(getActivity(),"Add Button Clicked",Toast.LENGTH_SHORT).show();
        DIVIDER=DIVIDER+2;
        pieDataMethod(DIVIDER);

    }
    public void removeMethodBtnClicked(){
        //Toast.makeText(getActivity(),"Remove Button Clicked",Toast.LENGTH_SHORT).show();

        if (DIVIDER>1){
            DIVIDER=DIVIDER-2;
            pieDataMethod(DIVIDER);
        }else {
            pieDataMethod(DIVIDER+1);
        }
    }

}
