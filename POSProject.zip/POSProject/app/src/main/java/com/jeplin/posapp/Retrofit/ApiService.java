package com.jeplin.posapp.Retrofit;

/**
 * Created by jeplin on 21-12-2017.
 */

public class ApiService {

    //private static String BASE_URL="http://localhost/POSProjects/getLayout.php";
    private static String BASE_URL="http://10.0.2.2/POSProjects/";
//    private static String BASE_URL="https://jsonplaceholder.typicode.com/";

    public static ApiInterface getApiClient(){
        return ApiClient.getClient(BASE_URL).create(ApiInterface.class);
    }


}
